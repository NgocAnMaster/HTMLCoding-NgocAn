// // // Get the modal
// // var modal = document.getElementById("mobileMenuId");
// //
// // // Get the button that opens the modal
// // var btn = document.getElementById("menuIconId");
// //
// // // When the user clicks on the button, open the modal
// // btn.onclick = function() {
// //     modal.style.display = "block";
// // }
// //
// // // When the user clicks anywhere outside of the modal, close it
// // window.onclick = function(event) {
// //     if (event.target == modal) {
// //         modal.style.display = "none";
// //     }
// // }
// function navigationMenu() {
//     var x = document.getElementById("mobileMenuId");
//     if (x.style.display === "block") {
//         x.style.display = "none";
//     } else {
//         x.style.display = "block";
//     }
// }